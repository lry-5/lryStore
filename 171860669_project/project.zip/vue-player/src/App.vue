<template>
  <div id="app" class="small-container">
    <div class="main-win" @contextmenu.prevent="updateXY" @mouseleave="mymenuVisible=false">
      <!-- 视频窗口 -->
      <video id="player" controls></video> 
      <!-- 文件选择框 -->
      <select class="infolist" v-model="fileId" @change="updateVideoSrc(1)">
        <option key="-1" label="文件列表" value="-1"></option>
        <option
          v-for="item in fileInfoes"
          :key="item.id"
          :label="item.name"
          :value="item.id"
        ></option>
      </select>
      <!-- 调节清晰度和播放速率的菜单 -->
      <div id="mymenu" v-show="mymenuVisible" ref="mymenu">
        <select v-model="definition" @change="updateVideoSrc(0)">          
          <option v-for="item in definitions" :key="item" :label="item" :value="item"></option>
        </select>
        <select v-model="rate" @change="updateRate()">
          <option key="0.75" label="0.75×" value="0.75"></option>
          <option key="1" label="1×" value="1"></option>
          <option key="1.5" label="1.5×" value="1.5"></option>
        </select>
      </div>
    </div>
  </div>
</template>

<script>
// import StudentTable from "./components/StudentTable.vue";
// import StudentForm from "./components/StudentForm.vue";
// import VcsVideo from "./components/vcs-video.vue";
// var video = document.getElementById("player");//获得播放元素

export default {
  name: "App",
  components: {},
  data() {
    return {
      rate: 1,
      fileId: -1,
      fileName: "",     
      mymenuVisible: false,
      definition: "360p",
      definitions: Array,
      prefix: "http://localhost:8083/",
      videoUrl: "",
      fileInfoes: Array
    };
  },

  mounted() {
    this.getInfoList();
  },

  methods: {
    updateXY(event) {//更新鼠标右键时鼠标的位置
      this.mymenuVisible = !this.mymenuVisible;//设置菜单可见或不可见
      if (!this.mymenuVisible) return;
      let x = event.offsetX;
      let y = event.offsetY;
      let el = document.getElementById("mymenu");//获取DOM中的菜单元素
      //更新菜单的位置
      el.style.top = y + "px";
      el.style.left = x + "px";
    },

    updateRate() {//更新播放速率
      let video = document.getElementById("player"); //获得播放元素
      video.playbackRate = this.rate;
    },

    updateVideoSrc(isOther) {//更新视频源        
      if (this.fileId < 0) return;
      let video = document.getElementById("player"); //获得播放元素
      let currentTime = video.currentTime;

      this.fileInfoes.forEach(item => {
        if (this.fileId == item.id) {
          //找到选中的fileInfo
          this.fileName = item.name;
          this.definitions = item.definitions;
        }
      });

      video.src = this.prefix + "files/" + this.definition + "_" + this.fileName; //修改视频源
      video.play();
      if (isOther == 0) {
        console.log("not other");
        video.currentTime = currentTime; //改清晰度时进度不变
      } else {
        //不同文件
        console.log("is other");
        video.currentTime = 0; //换其他视频时重新开始
      }
      // this.getInfoList();//更新文件列表
    },

    async getInfoList() {//向服务器发送请求，获得文件列表
      console.log("infolist ** "+this.prefix+"infolist")
      try {
        const response = await fetch(this.prefix+'infolist');
        const data = await response.json();//包含文件列表的json
        this.fileInfoes = data._embedded.fileInfoList;//文件列表
        console.log("get Info List***" + this.fileInfoes[0].definitions);
      } catch (error) {
        console.error(error);
      }
    }
  }
};
</script>

<style>
/* @import "./css/video-container.css";
@import "./css/control.css";
@import "./css/progress.css"; */

/* button {
  background: #009435;
  border: 1px solid #009435;
} */

.small-container {
  width: 802px;
  height: 90%;
  padding: 0;
}

.main-win {
  /* overflow: auto; */
  height: 100%;
  top: 8%;
  position: absolute;
  /* background-color: black; */
}

.infolist{
  background: transparent;
  border:0;
  /* background-color: white; */
  /* background-color: #ece0d4; */
  /* color:black; */
}

#player {
  width: 800px;
  height: 450px;
}

#mymenu {
  /* width: 6em;
  height: 2.4em; */
  /* color: white; */
  background-color: black;
  position: absolute;
}

#mymenu select {
  width: 6em;
  /* height: 1.2em; */
  font-size: 1em;
  padding: 0;
  margin: 3px;
  color: white;
  background: black;
  border: 0;
}

#mymenu select option{
  background: grey;
  opacity: 0.5;
}
</style>
