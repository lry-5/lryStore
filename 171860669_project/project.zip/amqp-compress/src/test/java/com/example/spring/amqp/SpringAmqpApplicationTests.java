package com.example.spring.amqp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringAmqpApplicationTests {

	@Test
	void contextLoads() {
	}

}
