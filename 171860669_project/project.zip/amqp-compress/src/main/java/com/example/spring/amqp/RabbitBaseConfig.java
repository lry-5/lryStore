package com.example.spring.amqp;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import com.rabbitmq.client.Channel;

import org.springframework.amqp.core.AcknowledgeMode;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.Declarables;
import org.springframework.amqp.core.FanoutExchange;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.listener.SimpleMessageListenerContainer;
import org.springframework.amqp.rabbit.listener.api.ChannelAwareMessageListener;
// import org.springframework.boot.autoconfigure.amqp.RabbitProperties.Cache.Channel;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitBaseConfig {

    private static final int MAX_MSG_NUM = 1;
    private static final int MAX_TASK_NUM = 2;//
    private static final boolean NON_DURABLE = false;
    private static final String MY_QUEUE_NAME = "myQueue";
    // private static List<Thread> threads=new LinkedList<>();
    private static List<Thread> threads=new ArrayList<>();

    // public final static String FANOUT_QUEUE_1_NAME = "fanout.queue1";
    // public final static String FANOUT_QUEUE_2_NAME = "fanout.queue2";
    // public final static String FANOUT_EXCHANGE_NAME = "fanout.exchange";

    // public final static String TOPIC_QUEUE_1_NAME = "topic.queue1";
    // public final static String TOPIC_QUEUE_2_NAME = "topic.queue2";
    // public final static String TOPIC_EXCHANGE_NAME = "topic.exchange";
    // public static final String BINDING_PATTERN_IMPORTANT = "*.important.*";
    // public static final String BINDING_PATTERN_ERROR = "#.error";

    public static final String nfsPath = "Z:/";
    public static final String videosPath = nfsPath + "videos/";
    public static final String resourcesPath = nfsPath + "resources/";
    // public static final String rootPath=System.getProperty("user.dir") + "/";

    @Bean
    public Queue myQueue() {
        return new Queue(MY_QUEUE_NAME, NON_DURABLE);
    }

    // @Bean
    // public Declarables topicBindings() {
    // Queue topicQueue1 = new Queue(TOPIC_QUEUE_1_NAME, NON_DURABLE);
    // Queue topicQueue2 = new Queue(TOPIC_QUEUE_2_NAME, NON_DURABLE);

    // TopicExchange topicExchange = new TopicExchange(TOPIC_EXCHANGE_NAME,
    // NON_DURABLE, false);

    // return new Declarables(topicQueue1, topicQueue2, topicExchange,
    // BindingBuilder.bind(topicQueue1).to(topicExchange).with(BINDING_PATTERN_IMPORTANT),
    // BindingBuilder.bind(topicQueue2).to(topicExchange).with(BINDING_PATTERN_ERROR));
    // }

    // @Bean
    // public Declarables fanoutBindings() {
    // Queue fanoutQueue1 = new Queue(FANOUT_QUEUE_1_NAME, NON_DURABLE);
    // Queue fanoutQueue2 = new Queue(FANOUT_QUEUE_2_NAME, NON_DURABLE);

    // FanoutExchange fanoutExchange = new FanoutExchange(FANOUT_EXCHANGE_NAME,
    // NON_DURABLE, false);

    // return new Declarables(fanoutQueue1, fanoutQueue2, fanoutExchange,
    // BindingBuilder.bind(fanoutQueue1).to(fanoutExchange),
    // BindingBuilder.bind(fanoutQueue2).to(fanoutExchange));
    // }

    // 配置监听
    @Bean
    public SimpleMessageListenerContainer myQueueLister(ConnectionFactory connectionFactory) {
        System.out.println("simple message listener********");
        SimpleMessageListenerContainer container = new SimpleMessageListenerContainer(connectionFactory);
        // 设置监听的队列
        container.setQueues(new Queue(MY_QUEUE_NAME, NON_DURABLE));

        // 指定要创建的并发使用者数。
        container.setConcurrentConsumers(1);
        // 设置消费者数量的上限
        container.setMaxConcurrentConsumers(1);

        // 设置是否自动签收消费 为保证消费被成功消费，建议手工签收
        container.setAcknowledgeMode(AcknowledgeMode.MANUAL);

        container.setMessageListener(new ChannelAwareMessageListener() {
            @Override
            public void onMessage(Message message, Channel channel) throws Exception {
                // channel
                channel.basicQos(MAX_MSG_NUM, false);
                // 可以在这个地方得到消息额外属性
                MessageProperties properties = message.getMessageProperties();                
                String str = new String(message.getBody());
                System.out.println(MY_QUEUE_NAME + "收到消息:" + str);

                while(threads.size()>=MAX_TASK_NUM){
                    for(int i=threads.size()-1;i>=0;i--){
                        if(!threads.get(i).isAlive()){ 
                            System.out.println("remove thread");                           
                            threads.remove(i);
                        }
                    }
                    Thread.sleep(100);
                }
                Thread thr=new CompressThread(message, channel);
                thr.start();
                threads.add(thr);
                /*
                 * DeliveryTag 是一个单调递增的整数 第二个参数 代表是否一次签收多条，如果设置为 true,则所有 DeliveryTag 小于该
                 * DeliveryTag 的消息都会被签收
                 */                
                channel.basicAck(properties.getDeliveryTag(), false);
                System.out.println("ack**********");
            }
        });
        return container;
    }

}