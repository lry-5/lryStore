package com.example.spring.amqp;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.*;

import com.rabbitmq.client.Channel;

import org.springframework.amqp.core.Message;

import static com.example.spring.amqp.RabbitBaseConfig.*;

public class CompressThread extends Thread {
    private Message message;
    private Channel channel;
    private String compressApp = System.getProperty("user.dir") + "/../HandBrakeCLI-1.3.2/HandBrakeCLI";

    CompressThread(Message msg, Channel chl) {
        message = msg;
        channel = chl;
    }

    public Message getMessage() {
        return message;
    }

    @Override
    public void run() {
        String str = new String(message.getBody());
        System.out.println("run **** "+str);
        String[] strs = str.split("\\s+", 2);
        int height = Integer.parseInt(strs[0]);
        List<String> cmdList = Arrays.asList(compressApp, "-i", videosPath + strs[1], "-o",
                resourcesPath + strs[0] + "p_" + strs[1], "-e", "x264", "-l", strs[0], "-w",
                "" + (int) (height * 16 / 9));
        // 创建ProcessBuilder对象
        ProcessBuilder processBuilder = new ProcessBuilder();
        // 设置执行的第三方程序(命令)

        processBuilder.command(cmdList);
        // 将标准输入流和错误输入流合并，通过标准输入流读取信息就可以拿到第三方程序输出的错误信息、正常信息
        processBuilder.redirectErrorStream(true);
        try {
            // 启动一个进程
            Process process = processBuilder.start();
            // 由于前边将错误和正常信息合并在输入流，只读取输入流(子进程中命令行的运行结果)
            InputStream inputStream = process.getInputStream();
            // 将字节流转成字符流
            InputStreamReader reader = new InputStreamReader(inputStream, "gbk");
            // 字符缓冲区
            char[] chars = new char[1024];
            int len = -1;
            while ((len = reader.read(chars)) != -1) {
                String string = new String(chars, 0, len);
                // System.out.println(str+" running********************");
                System.out.println(string);
            }

            inputStream.close();
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}