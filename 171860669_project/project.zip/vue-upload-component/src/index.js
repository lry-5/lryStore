module.exports = require('./FileUpload.vue')
