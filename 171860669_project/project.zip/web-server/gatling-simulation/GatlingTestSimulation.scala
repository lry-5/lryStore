package gatlingtest

import io.gatling.core.Predef._
import io.gatling.http.Predef._
import scala.concurrent.duration._

class GatlingTestSimulation extends Simulation {

  val httpProtocol = http
    .baseUrl("http://localhost:8083")

  // val login = exec(http("login_request").get("/login"))
  val infoes = exec(http("informations").get("/infolist"))
  val scn = scenario("TEST REST-SERVER").exec(infoes)
  // val scn = scenario("Testing REST-SERVER").exec(login,calculate)


  setUp(scn.inject(atOnceUsers(45)).protocols(httpProtocol))
}